import { Component, OnInit } from '@angular/core';
import { Product } from './product';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {


  productListTitle:string='Products List';
  _listFilter:string='';
  productsList:Product[];
  error:string;
  products:Product[];  
  product:Product;
  _listSearch:string;
  constructor(private productService:ProductService) {
      this._listFilter="";
      this._listSearch="";  
   }
   
   ngOnInit() {
      this.productService.getAllProductDetails().subscribe(
          _products=>{
              this.products=_products;
              this.productsList=this.products;
          },
          error=>{
              this.error=error;
          }
      )
   }

  get listFilter():string{
      return this._listFilter;
  }
  set listFilter(value:string){
      this._listFilter=value;
      this.productsList=this._listFilter ?
      this.doProductFiltering(this._listFilter):this.products;
  }

  doProductFiltering(filterBy:string):Product[]{
    filterBy=filterBy.toLowerCase();  
    return this.products.filter(product =>
    product.productName.toLowerCase().indexOf(filterBy)!==-1);
  }
  onRatingClicked(message:string):void{
      this.productListTitle='Products List!!! '+message;
  }
  

  

}
