import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService } from 'src/app/services/product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  pageTitle:string='Add Product'
  errorMessage:string

  constructor(private productService:ProductService, private router:Router) { }

  ngOnInit() {}

  onSubmit(product:Product){
    this.productService.acceptProductDetails(product).subscribe(
      errorMessage=>{
        this.errorMessage=errorMessage
      }
    )
    this.router.navigate(['/products'])
  }
}